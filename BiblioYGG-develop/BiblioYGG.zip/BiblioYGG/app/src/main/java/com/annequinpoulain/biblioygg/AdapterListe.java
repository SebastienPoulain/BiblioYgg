package com.annequinpoulain.biblioygg;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AdapterListe extends RecyclerView.Adapter<AdapterListe.MonViewHolder> {
    private List<Livre> listeLivres;

    public AdapterListe(List<Livre> liste){
        listeLivres = liste;
    }

    @NonNull
    @Override
    public AdapterListe.MonViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.liste,parent,false);
        return new MonViewHolder(view);
    }

    public void onBindViewHolder(@NonNull MonViewHolder holder,int position){
        holder.tvNom.setText(listeLivres.get(position).getNom());
        holder.tvPrix.setText(String.valueOf(listeLivres.get(position).getPrix()));
    }

    @Override
    public int getItemCount(){
        return listeLivres.size();
    }

    public void ModifierItem(int index){
        listeLivres.get(index).setNom("gameOfthrones");
        listeLivres.get(index).setPrix(33);
        notifyItemChanged(index);
    }
    public void ajoutItem(Livre livre){
        listeLivres.add(livre);
        notifyItemInserted(listeLivres.size()-1);
    }
    public void supprimerItem(int index){
        listeLivres.remove(index);
        notifyItemRemoved(index);
    }


    public class MonViewHolder extends RecyclerView.ViewHolder{
        TextView tvNom;
        TextView tvPrix;
        public MonViewHolder(View view){
            super(view);
            tvNom = view.findViewById(R.id.tvNom);
            tvPrix = view.findViewById(R.id.tvPrix);
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                }
            });
        }
    }
}

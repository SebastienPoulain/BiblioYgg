package com.annequinpoulain.biblioygg;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

public class ProfilActivity extends AppCompatActivity implements loginDialog.LoginDialogListener {

    private boolean login = true;
    private boolean erreur = false;
    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    AlertDialog.Builder builder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil);
        androidx.appcompat.widget.Toolbar toolbar = (androidx.appcompat.widget.Toolbar) findViewById(R.id.app_bar);
        setSupportActionBar(toolbar);
        toolbar.setLogo(R.drawable.biblioygg);
        toolbar.setTitle("");
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.login, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        if (login) {
            menu.findItem(R.id.login).setVisible(false);
            menu.findItem(R.id.logout).setVisible(true);
            menu.findItem(R.id.ajouter).setVisible(true);
            menu.findItem(R.id.modifier).setVisible(true);
            menu.findItem(R.id.supprimer).setVisible(true);
        }
        else
        {
            menu.findItem(R.id.login).setVisible(true);
            menu.findItem(R.id.logout).setVisible(false);
            menu.findItem(R.id.ajouter).setVisible(false);
            menu.findItem(R.id.modifier).setVisible(false);
            menu.findItem(R.id.supprimer).setVisible(false);
        }

        return super.onPrepareOptionsMenu(menu);
    }

    public void openDialog(){
        loginDialog loginDialog = new loginDialog();
        loginDialog.show(getSupportFragmentManager(), "Login Dialog");
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.login:
                openDialog();
                break;
            case R.id.logout:
                login = false;
                invalidateOptionsMenu();
                break;
            case R.id.ajouter:
                ((AdapterListe)adapter).ajoutItem(new Livre("écran",233));
                break;

            case R.id.modifier:
                ((AdapterListe)adapter).ModifierItem(0);
                break;

            case R.id.supprimer:
                ((AdapterListe)adapter).supprimerItem(1);
                break;
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void applyTexts(String username, String password) {
        if (username.equals("johndoe@mail.com") && password.equals("projetsession")){
            erreur = false;
            login = true;
            invalidateOptionsMenu();
            Intent intent = new Intent (this, ProfilActivity.class);
            startActivity(intent);
        }
        else if(username.equals("") && password.equals("")){
            erreur = true;
            Toast.makeText(getApplicationContext(), "Veuillez entrer votre adresse email et votre mot de passe", Toast.LENGTH_LONG).show();

        }
        else {
            erreur = true;
            Toast.makeText(getApplicationContext(), "Veuillez entrer les informations correspondant au compte de john doe", Toast.LENGTH_LONG).show();
        }
    }
}
